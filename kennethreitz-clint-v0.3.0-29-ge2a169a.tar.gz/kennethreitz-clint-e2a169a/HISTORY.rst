History
-------

0.3.0
+++++

* Python 3 support!

0.2.4
+++++

* New eng module
* Win32 Bugfix


0.2.3
+++++

* Only init colors if they are used (iPython compatability)
* New progress module
* Various bugfixes


0.2.2
+++++

* Auto Color Disabling
* Progress Namespace Change
* New Progress Bars
* textui.puts newline fix


0.2.1 (2011-03-24)
++++++++++++++++++

* Python 2.5 Support
* List of available colors


0.2.0 (2011-03-23)
++++++++++++++++++

* Column Printing!!!
* (Auto/Manual) Disabling of Colors
* Smarter Colors
* max_width, min_width
* Strip cli colors
* bug fixes


0.1.2 (2011-03-21)
++++++++++++++++++

* Bugfixes


0.1.1 (2011-03-20)
++++++++++++++++++

* Bugfixes
* Indent Newline Injection
* resources: flags, not_flags, files, not_files
* Lots of Examples



0.1.0 (2011-03-20)
++++++++++++++++++

* Initial Release!

