#!/usr/bin/env sh

python unicode.py こんにちは。 unicode.json < unicode.json
