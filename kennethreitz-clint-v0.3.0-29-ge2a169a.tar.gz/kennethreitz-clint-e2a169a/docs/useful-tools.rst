Useful Tools
============

IPython
-------

::

    $ pip install ipython



BPython
-------

::

    $ pip install bpython
