#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""Clint Test Suite."""

import unittest


class TablibTestCase(unittest.TestCase):
    """Tablib test cases."""

    def setUp(self):
        import clint


    def tearDown(self):
        pass

if __name__ == '__main__':
    unittest.main()
